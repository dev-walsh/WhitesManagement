# Whites Management - AWS EC2 Cloud Version

## Quick Start for AWS EC2

1. **Launch EC2 Instance**
   - Ubuntu 22.04 LTS
   - t3.small or larger recommended
   - Security group: ports 22, 80, 443, 5000

2. **Upload and Setup**
   ```bash
   # Upload package to EC2
   scp -i your-key.pem -r . ubuntu@your-ec2-ip:~/whites-management/
   
   # Connect and run setup
   ssh -i your-key.pem ubuntu@your-ec2-ip
   cd whites-management
   chmod +x ec2_setup_script.sh
   ./ec2_setup_script.sh
   ```

3. **Access Application**
   - http://your-ec2-ip
   - Or your custom domain after DNS setup

## Features
- Production-ready cloud deployment
- Nginx reverse proxy
- SSL certificate support
- Automated backups
- Security hardening
- System monitoring

## Cloud Providers Supported
- AWS EC2 (primary)
- Hostinger VPS
- Any Ubuntu VPS provider

## Cost Estimates
- t3.micro: ~£8.50/month (Free tier eligible)
- t3.small: ~£17/month (Recommended)
- t3.medium: ~£34/month (High traffic)

## Support
See AWS_EC2_DEPLOYMENT.md for detailed instructions.
