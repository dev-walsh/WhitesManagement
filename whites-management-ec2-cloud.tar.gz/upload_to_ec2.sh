#!/bin/bash
# Helper script to upload to EC2
# Usage: ./upload_to_ec2.sh your-key.pem your-ec2-ip

if [ $# -ne 2 ]; then
    echo "Usage: $0 <key-file.pem> <ec2-ip-address>"
    echo "Example: $0 my-key.pem 1.2.3.4"
    exit 1
fi

KEY_FILE="$1"
EC2_IP="$2"

echo "Uploading Whites Management to EC2..."
scp -i "$KEY_FILE" -r . ubuntu@"$EC2_IP":~/whites-management/

echo "Connecting to EC2 for setup..."
ssh -i "$KEY_FILE" ubuntu@"$EC2_IP" "cd whites-management && chmod +x ec2_setup_script.sh && ./ec2_setup_script.sh"
