# Whites Management - Windows Offline Version

## Quick Start for Windows

1. **Install Python 3.11**
   - Download from python.org
   - Make sure to check "Add Python to PATH"

2. **Run Installation**
   ```cmd
   install_packages.bat
   ```

3. **Start Application**
   ```cmd
   start_app.bat
   ```

4. **Access Application**
   - Open browser to: http://localhost:5000

## Features
- Complete offline operation
- Local CSV data storage
- Vehicle and machine inventory management
- Tool hire and rental tracking
- Maintenance records
- Dashboard and statistics

## Files Included
- Application source code
- Windows batch files for easy setup
- Offline documentation
- All dependencies included

## Requirements
- Windows 10/11
- Python 3.11 or higher
- 2GB RAM minimum
- 1GB disk space

## Support
See README_WINDOWS.md and TROUBLESHOOTING.md for detailed instructions.
