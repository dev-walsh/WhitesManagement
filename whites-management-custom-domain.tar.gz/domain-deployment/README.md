# Whites Management - Custom Domain Deployment

## Overview
This package contains everything needed to deploy Whites Management on your own domain using various hosting providers.

## Quick Start Options

### Option 1: VPS (Any Provider)
1. Launch Ubuntu 22.04 VPS
2. Upload this package to server
3. Run: `./scripts/universal_vps_setup.sh`
4. Upload application files
5. Configure SSL

### Option 2: Platform as a Service
1. Connect to your PaaS provider (Heroku, Railway, etc.)
2. Use included config files (Procfile, railway.json, etc.)
3. Deploy via Git or dashboard
4. Add custom domain in provider dashboard

### Option 3: Interactive Setup
1. Run: `./scripts/domain_setup_helper.sh`
2. Follow guided setup for your specific needs

## What's Included

### Core Application
- Complete Whites Management system
- Vehicle inventory management
- Machine/plant equipment tracking
- Tool hire and rental system
- Maintenance records
- Dashboard and statistics

### Deployment Tools
- Universal VPS setup script
- Platform-specific config files
- Domain setup helper
- SSL certificate automation
- Nginx configuration templates

### Documentation
- Provider-specific guides
- DNS configuration instructions
- SSL setup procedures
- Troubleshooting guides

## Supported Hosting Providers

### VPS Providers
- DigitalOcean ($5-20/month)
- Linode ($5-20/month)
- AWS EC2 ($8-50/month)
- Vultr ($3.50-20/month)
- Hetzner (€3-20/month)

### PaaS Providers
- Heroku ($7-25/month)
- Railway ($5-20/month)
- Render ($7-25/month)

## Requirements
- Ubuntu 22.04 (for VPS)
- Python 3.11 support
- 1GB RAM minimum (2GB recommended)
- Custom domain name

## Support
See CUSTOM_DOMAIN_DEPLOYMENT.md for detailed instructions.
