# Hosting Provider Specific Guides

## VPS Providers (Recommended)

### DigitalOcean
- Cost: $5-20/month
- Create Ubuntu 22.04 droplet
- Use universal_vps_setup.sh script
- Point domain A record to droplet IP

### Linode
- Cost: $5-20/month  
- Create Ubuntu 22.04 Linode
- Use universal_vps_setup.sh script
- Configure domain DNS in Linode manager

### AWS EC2
- Cost: $8-50/month
- Launch Ubuntu 22.04 instance
- Configure security groups (22, 80, 443)
- Use universal_vps_setup.sh script

### Vultr
- Cost: $3.50-20/month
- Deploy Ubuntu 22.04 server
- Use universal_vps_setup.sh script
- Configure DNS in Vultr dashboard

## Platform as a Service

### Heroku
- Cost: $7-25/month
- Uses included Procfile and runtime.txt
- Deploy via Git: git push heroku main
- Add custom domain in Heroku dashboard

### Railway
- Cost: $5-20/month
- Uses included railway.json
- Connect GitHub repository
- Add custom domain in Railway dashboard

### Render
- Cost: $7-25/month
- Build: pip install -r requirements.txt
- Start: streamlit run app.py --server.port=$PORT --server.address=0.0.0.0
- Add custom domain in Render dashboard

## DNS Configuration

For all providers, configure DNS:


## SSL Certificates

### VPS: Let's Encrypt (Free)


### PaaS: Automatic
Most platforms handle SSL automatically for custom domains.
