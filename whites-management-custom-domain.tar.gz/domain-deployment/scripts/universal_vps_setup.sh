#!/bin/bash
# Universal VPS Setup Script for Any Provider

set -e

echo "=== Universal VPS Setup for Whites Management ==="

# Update system
sudo apt update && sudo apt upgrade -y

# Install dependencies
sudo apt install -y python3.11 python3.11-venv python3-pip nginx git curl certbot python3-certbot-nginx ufw

# Create application directory
sudo mkdir -p /opt/whites-management
cd /opt/whites-management

# Create virtual environment
sudo python3.11 -m venv venv
sudo ./venv/bin/pip install --upgrade pip
sudo ./venv/bin/pip install streamlit pandas plotly xlsxwriter

# Get domain
echo "Enter your domain name (e.g., yourdomain.com):"
read DOMAIN

# Create systemd service
sudo tee /etc/systemd/system/whites-management.service > /dev/null <<SERVICE_EOF
[Unit]
Description=Whites Management Application
After=network.target

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/opt/whites-management
Environment=PATH=/opt/whites-management/venv/bin
ExecStart=/opt/whites-management/venv/bin/streamlit run app.py --server.port 5000 --server.address 0.0.0.0
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
SERVICE_EOF

# Create nginx configuration
sudo tee /etc/nginx/sites-available/whites-management > /dev/null <<NGINX_EOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;
    
    client_max_body_size 50M;
    
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 86400;
    }
}
NGINX_EOF

# Enable site
sudo ln -s /etc/nginx/sites-available/whites-management /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx

# Configure firewall
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw --force enable

# Set permissions
sudo chown -R www-data:www-data /opt/whites-management
sudo chmod -R 755 /opt/whites-management

# Enable services
sudo systemctl daemon-reload
sudo systemctl enable whites-management nginx

echo ""
echo "=== Setup Complete ==="
echo "1. Upload your application files to /opt/whites-management/"
echo "2. Start the service: sudo systemctl start whites-management"
echo "3. Setup SSL: sudo certbot --nginx -d $DOMAIN -d www.$DOMAIN"
echo ""
echo "Your application will be available at: http://$DOMAIN"
echo "After SSL setup: https://$DOMAIN"
